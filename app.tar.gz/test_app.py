import flet as ft
import random
import time

MAX_TIME_EASY = 2
MAX_TIME_MEDIUM = 1
MAX_TIME_HARD = 0.5
PADDING_SPACE = 300
SHRINK_STEP = 5
MINIMUM_SIZE = 5
CLICKS_PER_SHRINK = 5

COLOR_COST = 10

def main(page: ft.Page):
    score = 0
    high_score = 0
    coins = 0  # Initialize coins
    last_click_times = [0, 0, 0]  # Initialize last_click_time for all dots to 0
    default_dot_size = 50
    dot_color = ft.colors.RED
    current_difficulty = "easy"  # Default difficulty
    current_ball_count = 3  # Default to 3 balls
    click_count = 0
    dot_size = default_dot_size  # Current dot size initialized to default
    clicked_dots = [False, False, False]

    def start_game(e=None):
        nonlocal score, last_click_times, click_count, dot_size, clicked_dots
        print("Game started")  # Debug print
        score = 0
        last_click_times = [time.time()] * current_ball_count
        click_count = 0
        set_difficulty()
        set_ball_count()  # Open the ball count dialog every time the game starts
        dot_size = default_dot_size  # Reset dot size to default
        for i, dot in enumerate(dots):
            dot.width = dot.height = dot_size
            dot.visible = i < current_ball_count
            dot.bgcolor = dot_color
        score_text.value = f"Score: {score}"
        message_text.value = ""
        clicked_dots = [False] * 3
        move_dot(None, is_initial=True)
        page.update()

    def move_dot(e, is_initial=False):
        nonlocal score, high_score, last_click_times, click_count, dot_size, coins, clicked_dots

        if not is_initial:
            current_time = time.time()
            # Check if more than MAX_TIME seconds have passed since the last click on any dot
            for i in range(current_ball_count):
                if current_time - last_click_times[i] > max_time_for_difficulty():
                    lose_game()
                    return

            if e.control in dots:
                index = dots.index(e.control)
                last_click_times[index] = current_time
                clicked_dots[index] = True
                dots[index].visible = False

            if all(clicked_dots[:current_ball_count]):
                # Increase score and coins
                score += 1
                coins += 1
                click_count += 1
                if score > high_score:
                    high_score = score
                    high_score_text.value = f"High Score: {high_score}"

                # Update score and coins display
                score_text.value = f"Score: {score}"
                coins_text.value = f"Coins: {coins}"

                # Check if it's time to shrink the dots
                if click_count >= CLICKS_PER_SHRINK:
                    click_count = 0
                    shrink_dot()

                clicked_dots = [False] * 3

                # Reposition dots after all have been clicked
                for dot in dots[:current_ball_count]:
                    new_x = random.randint(PADDING_SPACE, int(page.window.width - dot.width - PADDING_SPACE))
                    new_y = random.randint(PADDING_SPACE, int(page.window.height - dot.height - PADDING_SPACE))
                    dot.left = new_x
                    dot.top = new_y
                    dot.visible = True

                last_click_times = [time.time()] * current_ball_count

        page.update()

    def lose_game():
        for dot in dots:
            dot.visible = False
        message_text.value = "You lost!"
        restart_button.visible = True
        page.update()

    def open_shop(e):
        shop_dialog.open = True
        page.update()

    def select_color(e):
        nonlocal dot_color, coins
        color = e.control.data
        if coins >= COLOR_COST:
            coins -= COLOR_COST
            dot_color = color
            for dot in dots:
                dot.bgcolor = dot_color
            coins_text.value = f"Coins: {coins}"
            shop_dialog.open = False
            page.update()
        else:
            message_text.value = "Not enough coins!"
            page.update()

    def set_difficulty():
        difficulty_dialog.open = True

    def apply_difficulty(e):
        nonlocal current_difficulty, last_click_times
        current_difficulty = e.control.data
        last_click_times = [time.time()] * current_ball_count  # Start timer after difficulty is chosen
        difficulty_dialog.open = False
        page.update()

    def set_ball_count():
        ball_count_dialog.open = True

    def apply_ball_count(e):
        nonlocal current_ball_count
        current_ball_count = int(e.control.data)
        ball_count_dialog.open = False
        for i, dot in enumerate(dots):
            dot.visible = i < current_ball_count
        page.update()

    def max_time_for_difficulty():
        if current_difficulty == "easy":
            return MAX_TIME_EASY
        elif current_difficulty == "medium":
            return MAX_TIME_MEDIUM
        elif current_difficulty == "hard":
            return MAX_TIME_HARD
        else:
            return MAX_TIME_EASY

    def shrink_dot():
        nonlocal dot_size
        if dot_size > MINIMUM_SIZE:
            dot_size -= SHRINK_STEP
            for dot in dots:
                dot.width = dot.height = dot_size

    dots = [ft.Container(
                width=default_dot_size,  # Initialize dot size with default size
                height=default_dot_size,
                bgcolor=dot_color,
                border_radius=default_dot_size // 2,
                on_click=move_dot,
                visible=False  # Initially invisible
            ) for _ in range(3)]

    score_text = ft.Text(value="Score: 0")
    high_score_text = ft.Text(value="High Score: 0")
    coins_text = ft.Text(value="Coins: 0")
    message_text = ft.Text(value="", size=20, color=ft.colors.RED)
    restart_button = ft.ElevatedButton(text="Restart", on_click=start_game, visible=False)
    shop_button = ft.ElevatedButton(text="Item Shop", on_click=open_shop)

    color_choices = [ft.colors.RED, ft.colors.GREEN, ft.colors.BLUE, ft.colors.YELLOW, ft.colors.PURPLE]
    shop_items = [
        ft.Container(
            width=50,
            height=50,
            bgcolor=color,
            border_radius=25,
            on_click=select_color,
            data=color
        ) for color in color_choices
    ]

    shop_dialog = ft.AlertDialog(
        title=ft.Text("Choose a Color (Cost: 10 coins)"),
        content=ft.Row(shop_items, alignment="center"),
        actions=[
            ft.TextButton("Close", on_click=lambda e: setattr(shop_dialog, 'open', False))
        ]
    )

    difficulty_items = [
        ft.TextButton("Easy", on_click=apply_difficulty, data="easy"),
        ft.TextButton("Medium", on_click=apply_difficulty, data="medium"),
        ft.TextButton("Hard", on_click=apply_difficulty, data="hard")
    ]

    difficulty_dialog = ft.AlertDialog(
        title=ft.Text("Select Difficulty"),
        content=ft.Column(difficulty_items, alignment="center"),
        actions=[]
    )

    ball_count_items = [
        ft.TextButton("1 Ball", on_click=apply_ball_count, data="1"),
        ft.TextButton("2 Balls", on_click=apply_ball_count, data="2"),
        ft.TextButton("3 Balls", on_click=apply_ball_count, data="3")
    ]

    ball_count_dialog = ft.AlertDialog(
        title=ft.Text("Select Number of Balls"),
        content=ft.Column(ball_count_items, alignment="center"),
        actions=[]
    )

    page.overlay.append(shop_dialog)
    page.overlay.append(difficulty_dialog)
    page.overlay.append(ball_count_dialog)

    stack = ft.Stack(dots, expand=True)

    page.add(score_text, high_score_text, coins_text, message_text, restart_button, shop_button, stack)
    start_game()

ft.app(target=main)
